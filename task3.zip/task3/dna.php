<?php 

$errname="";

function DnaValidation(){

  if (isset($_POST['submit'])) {
    $dna = $_POST['dna'];

    $dnaregex= '/^[ACGT-acgt]+$/';
    if ( preg_match($dnaregex,$dna)) {
      $dna= strtoupper($dna);
        echo $dna;
    }else{
        $errname = "please enter this charactar only[A,C,G,T]";
        echo $errname;
    }
}
};
function calculateLength(){
  if (isset($_POST['length'])) {
    $dna = $_POST['dna'];
    $dnaregex= '/^[ACGT-acgt]+$/';
    if ( preg_match($dnaregex,$dna)) {
        $strle= strlen($dna);
       

    echo $strle;
    }else{
        $errname = "please enter this charactar only[A,C,G,T]";
        echo $errname;
    }
}
};
//CONVERT TO DNA
if (isset($_POST['submit'])) {
DnaValidation();
}

function ConvertToRNA(){
  if (isset($_POST['convert'])) {
     $dna = $_POST['dna'];
    DnaValidation();
    $rna= $_POST['convert'];
   $dnaregex= '/^[ACGT-acgt]+$/';
      if ( preg_match($dnaregex,$dna)) {
        preg_replace( "/t/i","U",$dna);
        $rna= preg_replace( "/t/i","U",$dna);
        $rna= strtoupper($rna);
        echo $rna;
     }else{
        $errname = "please enter this charactar only[A,C,G,T,U]";
        echo $errname;
    }
}
};
//convert to RNA
if (isset($_POST['convert'])) {
ConvertToRNA();
}
//calculate length
if (isset($_POST['length'])) {
  calculateLength();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Website Form</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <h1>DNA </h1>
    <form method="post" action="" >
      <input type="text" placeholder="Enter your DNA"  name="dna">
      <div class="button-group">
        <button name="submit" type="submit">Submit</button>
        <button  name="length" type="submit">Get length</button>
        <button name="convert" type="submit">convert to RNA</button>
      </div>
    </form >
  </div>
</body>
</html>