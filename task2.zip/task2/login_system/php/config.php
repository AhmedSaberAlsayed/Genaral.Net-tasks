<?php 

$con = mysqli_connect("localhost","root","","currency_converter") or die("Couldn't connect");

?> 