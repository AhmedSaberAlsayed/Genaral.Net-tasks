<!-- <?php
      //session_start();
      //session_destroy();
     // header("Location: dashbord.php");
?> 

<?php


$id =  $_GET['id'];

$connection =  mysqli_connect("localhost","root","","currency_converter");
$query = mysqli_query($connection,"DELETE FROM `user` WHERE `id` = $id ");

if(mysqli_affected_rows($connection) >0){
    // sleep(5);
    
    header("location: ../index.php");
}else{
    echo "user not deleted";
}