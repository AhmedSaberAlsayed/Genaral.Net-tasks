<?php
include "../task_gd/convert.php";
$id = $_GET['id'];


if(isset($id)){
    $connection =  mysqli_connect("localhost","root","","currency_converter");
    $query = mysqli_query($connection,"SELECT * FROM `currency` WHERE `id` = '$id'");
    $row =  mysqli_fetch_assoc($query);
}

?>
<?php
    if(isset($_POST['update'])){
        $name=$_POST['name'];
        $value =$_POST['value'];
        $id=$_GET['id'];

        $connection =  mysqli_connect("localhost","root","","currency_converter");
        $query = mysqli_query($connection, "UPDATE currency SET id='$id', name='$name', value='$value' WHERE Id=$id ");
        
         header("Location: ../dashbord.php");
    }

    // if (isset($_POST['amount'])) {

    //     $new = ($_POST['amount'] - $toop['value']) * $doown['value'];
    
    //     $new2 = $new + $toop['value'];
    //     // echo $new . ' ' . $doown['value'] . ' ' . $toop['value'] . ' ' . $new2;
    //     mysqli_query($connection, "UPDATE `currency` SET `value`='$new2' WHERE name ='$to'");
    
    // }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="box form-box">

        <header>Login</header>
        <form action="" method="post">
            <div class="field input">
                <input type="text" value="<?= $row['name']; ?>" name="name">
            </div>
            <div class="field input">
                <input type="text" value="<?= $row['value']; ?>" name="value">
            </div>
            <div class="field">
                <input  class="btn"  type="submit" name="update" value="update">
            </div>
        </form> 
    </div>
</div>

</body>
</html>