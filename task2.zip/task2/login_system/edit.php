<?php
$id = $_GET['id'];


if(isset($id)){

    $connection =  mysqli_connect("localhost","root","","currency_converter");
    $query = mysqli_query($connection,"SELECT * FROM `user` WHERE `id` = $id");

    $row =  mysqli_fetch_assoc($query);
}

?>
<?php
    if(isset($_POST['update'])){
        $username=$_POST['username'];
        $email= $_POST['email'];
        $password =$_POST['password'];
        $age =$_POST['age'];
        $id=$_GET['id'];

        $connection =  mysqli_connect("localhost","root","","currency_converter");
        $query = mysqli_query($connection, "UPDATE user SET id='$id', age='$age', username='$username', email='$email', password='$password'  WHERE Id=$id ");
        
        header("Location: ../dashbord.php");
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="box form-box">
    <header>update</header>
        <form action="" method="post">
        <div class="field input">
            <input type="text" value="<?= $row['username']; ?>" name="username">
        </div>
        <div class="field input">
            <input type="text" value="<?= $row['email']; ?>" name="email">
        </div>
        <div class="field input">
            <input type="text" value="<?= $row['password']; ?>" name="password">
        </div>
        <div class="field input">
            <input type="text" value="<?= $row['age']; ?>" name="age">
        </div>
        <div class="field">
            <input class="btn" type="submit" name="update" value="update">
        </div>
        </form> 
    </div>
</div>
</body>
</html>