<?php 
  include 'convert.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=1">
<title>Home</title>
<link rel="stylesheet" href="style/bootstrap.css">
  <link rel="stylesheet" href="style/bootstrap.min.css">
  <link rel="stylesheet" href="style/bootstrap.min.css.map"> 
  <link rel="stylesheet" type="text/css" href="style/index.css">

</head>
<body>

<form action="" method="post">
<div class="containerr container ">
    <h1>Currency Converter</h1>
    <div class="row  ">
      <div class="col  ">
      <select name="from" class="currency">
        <!-- <option value="select">select</option> -->
        <option value="USD">USD</option>
        	<option value="EGP">EGP</option>
          <option value="EUR">EUR</option>
          <option value="SAR">SAR</option>
          <option value="KWD">KWD</option>
          <option value="UED">UED</option>
        </select>

        <input class="  " type="number" step="any" name="amount" id="input_currency">
      </div>
      <div class="col  ">
      <select name="to" class="currency">
        <!-- <option value="select">select</option> -->
        	<option value="EGP">EGP</option>
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="SAR">SAR</option>
          <option value="KWD">KWD</option>
          <option value="UED">UAD</option>
          
        </select>
        <input class=" col-sm-12 col-md-6 col-lg-6 " type="text" name="result" id="output_currency" disabled value=" <?php
        if(empty($amount)){
          echo " ";
        }else{
          echo $amount * $td;
        } 
         ?> " >
      </div>
    </div>
    <button id="myButton"  name="submit">convert</button>
    <!-- <script>
  document.getElementById('myButton').addEventListener('click', function(event) {
    event.preventDefault();
  });
</script> -->







<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    $('#myButton').click(function(event) {
      event.preventDefault(); // إلغاء السلوك الافتراضي للزرار

      // أداء المهمة بواسطة AJAX
      $.ajax({
        url: 'index.php',
        type: 'POST',
        data: {param1: 'قيمة1', param2: 'قيمة2'},
        success: function(response) {
          // تحديث المحتوى بناءً على الاستجابة المستلمة
          $('#result').html(response);
        },
        error: function(xhr, status, error) {
          // التعامل مع أي خطأ في الطلب
          console.error(error);
        }
      });
    });
  });
</script> -->








</script>
</div>
</form>

<!-- 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" src="style/index.js"></script> -->
</body>
</html>
