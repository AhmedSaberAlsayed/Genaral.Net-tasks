<?php

        if (isset($_POST['amount'])) {
          $connection = mysqli_connect("localhost", "root", "", "currency_converter");
          // the amount of currency will be exchang
          $amount = $_POST['amount'];
          filter_var ($amount,FILTER_SANITIZE_NUMBER_FLOAT,) ;
          // currency exchange from
          $from = $_POST['from'];
          // select the value of currency (from)
          $down = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name ='$from'");
          // currency exchange to
          $to = $_POST['to'];
          // select the value of currency (to)
          $top = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name = '$to' ");

          $toop = mysqli_fetch_assoc($top);
          $doown = mysqli_fetch_assoc($down);

          $td = $toop['value'] / $doown['value'];   
        }
    
        ?>