<?php
session_start();
$connection =  mysqli_connect("localhost","root","","currency_converter");
$query = mysqli_query($connection,"SELECT * FROM `currency`");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Currency Table</title>
  <link rel="stylesheet" type="text/css" href="dashbord.css">
  <link rel="stylesheet" href="login_system/style/bootstrap.css">
  <link rel="stylesheet" href="login_system/style/bootstrap.min.css">
  <link rel="stylesheet" href="login_system/style/bootstrap.min.css.map">
</head>
<body>
<header>
        <h1>Dashboard</h1>
      </header>
  <div class="m-4" >
<!-- start of currency Table -->
      <h1>currency Table:</h1>

  <table class="  mb-5">
    <thead>
      <tr>
      <th>#</th>
        <th>Currency</th>
        <th>Code</th>
        <th>value</th>
        <th>update</th>
        <th>  <a class="btn btn-primary" href="code.php?id=<?= $row['id']?>">add</a> </th>
      </tr>
    </thead>
    <tbody>
      <?php while( $row = mysqli_fetch_assoc($query) ):?>
      <tr>
      <td><?php echo $row['id']?> </td>
        <td><?php echo $row['name']?> </td>
        <td><?php echo $row['name']?></td>
        <td><?php echo $row['value']?></td>
        <!-- <td><a href="update.php?id= <?= $user['id']; ?>">update</a></td> -->
        <td> <a class="btn btn-primary" href="login_system/edit_currency.php?id=<?= $row['id']?>">update</a></td>
        <!-- <td> <a class="btn btn-primary" href="code.php?id=<?= $row['id']?>">add</a></td> -->
      </tr>
      <?php endwhile; ?>
      <!-- Add more rows here as needed -->
    </tbody>
  </table>
<!-- end of currency Table -->

<!-- start of user Table -->
  <h1>user Table:</h1>

  <table class=" mb-5">
    <thead>
      <tr>
      <th>#</th>
        <th>usernamed</th>
        <th>email</th>
        <th>password</th>
        <th>age</th>
        <th>update</th>
        <th>delet</th>
        <th>  <a class="btn btn-primary" href="adduser.php">add </a> </th>


      </tr>
    </thead>
    <tbody>
    <?php
  include 'user.php';
while($row = mysqli_fetch_assoc($query)):?>
      <tr>
      <td><?php echo $row['id']?> </td>
        <td><?php echo $row['username']?></td>
        <td><?php echo $row['email']?></td>
        <td><?php echo $row['password']?></td>
        <td><?php echo $row['age']?></td>
        <td><a  class="btn btn-primary" href="login_system/edit.php?id=<?= $row['id']?>">update</a></td>
        <td><a class="btn btn-danger" href="login_system/php/logout.php?id=<?= $row['id']?>">delet</a></td>
      </tr>
    <?php endwhile; ?>
      <!-- Add more rows here as needed -->
    </tbody>
  </table>
<!-- end of user Table -->
  </div>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
	<title>Search Bar using PHP</title>
</head>
<body>

<form method="post">
<label>Search</label>
<input type="text" name="search">
<input type="submit" name="submit">
	
</form>

</body>
</html>

<?php

$con = new PDO("mysql:host=localhost;dbname=currency_converter",'root','');

if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `currency` WHERE Name = '$str'" );

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
				<th>Name</th>
				<th>Description</th>
			</tr>
			<tr>
      <td><?php echo $row->id;?></td>
				<td><?php echo $row->name; ?></td>
				<td><?php echo $row->value;?></td>
        

        <td> <a class="btn btn-primary" href="login_system/edit_currency.php?id=<?= $row['id']?>">update</a></td>

			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name Does not exist";
		}
}

?>
