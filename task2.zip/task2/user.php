<?php 

// connection of database
$connection =  mysqli_connect("localhost","root","","currency_converter");
$query = mysqli_query($connection,"SELECT * FROM `user`");
?>





