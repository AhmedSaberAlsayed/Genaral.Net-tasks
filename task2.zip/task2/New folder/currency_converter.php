<?php

if(isset($_POST['amount'])){
$connection = mysqli_connect("localhost", "root", "", "currency_converter");

$amount = $_POST['amount'];
// down
$from = $_POST['from'];
$down = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name ='$from' ");
// top
$to = $_POST['to'];
$top = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name = '$to' ");

$toop = mysqli_fetch_assoc($top);
$doown = mysqli_fetch_assoc($down);
$td = $toop['value'] / $doown['value'];
echo $amount * $td;
}
?>
