<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Money Exchange</title>
  <link rel="stylesheet" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- FontAweome CDN Link for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>

<body>
  <div class="wrapper">
    <header>Currency Converter</header>
    <form action="" method="post">
      <div class="amount">
        <p>Enter Amount</p>
        <input type="text" value="1" name="amount">
      </div>
      <div class="drop-list">
        <div class="from">
          <p>From</p>
          <div class="select-box">
            <img src="https://flagcdn.com/48x36/us.png" alt="flag">
            <select name="from"> <!-- Options tag are inserted from JavaScript --> </select>
          </div>
        </div>
        <div class="icon"><i class="fas fa-exchange-alt"></i></div>
        <div class="to">
          <p>To</p>
          <div class="select-box">
            <img src="https://flagcdn.com/48x36/np.png" alt="flag">
            <select name="to"> <!-- Options tag are inserted from JavaScript --> </select>
          </div>
        </div>
      </div>
      <div class="exchange-rate">


        <?php

        if (isset($_POST['amount'])) {
          $connection = mysqli_connect("localhost", "root", "", "currency_converter");

          $amount = $_POST['amount'];
          // down
          $from = $_POST['from'];
          $down = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name ='$from' ");
          // top
          $to = $_POST['to'];
          $top = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name = '$to' ");

          $toop = mysqli_fetch_assoc($top);
          $doown = mysqli_fetch_assoc($down);

          $td = $toop['value'] / $doown['value'];

          echo $amount * $td;

        }
        ?>


      </div>
      <input type="submit" value="Get Exchange Rate">
    </form>
  </div>




  <script src="java.js"></script>
  <script src="java2.js"></script>

</body>

</html>