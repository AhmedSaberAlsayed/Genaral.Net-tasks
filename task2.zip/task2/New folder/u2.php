<?php
if (isset($_POST['amount'])) {
    $connection = mysqli_connect("localhost", "root", "", "currency_converter");

    $amount = $_POST['amount'];
    // down
    $from = $_POST['from'];
    $down = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name ='$from' ");
    $doown = mysqli_fetch_assoc($down);
    // top
    $to = $_POST['to'];
    $top = mysqli_query($connection, "SELECT value FROM `currency` WHERE  name = '$to' ");
    $toop = mysqli_fetch_assoc($top);

    // ********toop= to && down=from *******
    $td = $toop['value'] / $doown['value'];
    $dt = $doown['value'] / $toop['value'];
}
if (isset($_POST['amount'])) {

    $new = ($_POST['amount'] - $toop['value']) * $doown['value'];

    $new2 = $new + $toop['value'];
    echo $new . ' ' . $doown['value'] . ' ' . $toop['value'] . ' ' . $new2;
    mysqli_query($connection, "UPDATE `currency` SET `value`='$new2' WHERE name ='$to'");

}