<?php












echo "

<form action='u2.php' method='post'>
<div class='amount'>
  <p>Enter Amount</p>
  <input type='text' value='' name='amount'>
</div>
<div class='drop-list'>
  <div class='from'>
    <p>From</p>
    <div class='select-box'>
      <img src='https://flagcdn.com/48x36/us.png' alt='flag'>
      <select name='from'> <!-- Options tag are inserted from JavaScript --> </select>
    </div>
  </div>
  <div class='icon'><i class='fas fa-exchange-alt'></i></div>
  <div class='to'>
    <p>To</p>
    <div class='select-box'>
      <img src='https://flagcdn.com/48x36/np.png' alt='flag'>
      <select name='to'> <!-- Options tag are inserted from JavaScript --> </select>
    </div>
  </div>
</div>
<div class='exchange-rate'>



</div>
<input type='submit' value='Get Exchange Rate'>
</form>
<script src='java.js'></script>
<script src='java2.js'></script>

";



?>